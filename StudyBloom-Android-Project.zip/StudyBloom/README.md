# StudyBloom — Android study & Pomodoro app

A native Android starter app based on the requested StudyBloom concept.

## Included
- Dark blue aesthetic UI
- Time-aware greeting
- Pomodoro focus timer + short/long break settings
- Foreground timer notification and 1-minute warning
- Daily study + break totals
- 10-minute minimum daily streak tracking
- Study Coins earned from completed focus sessions
- Forest collection with 26 tree species
- Aquarium collection with 26 aquatic species
- Unlockable species with increasing coin costs
- Task list stored locally
- Achievements/progression data foundation
- Optional distraction blocking using Android Accessibility Service
- Local/offline SharedPreferences storage

## Build/install
This is the complete Android Studio project. To make an APK:
1. Install Android Studio on a computer.
2. Open this folder as an existing Gradle project.
3. Let Android Studio install the requested Android SDK/Gradle components.
4. Select **Build > Build APK(s)**.
5. Copy the generated APK to your Android phone and install it.

For distraction blocking, open the app's Settings and then Android's Accessibility settings, enable StudyBloom, and turn on **Block distracting apps**. Android requires the user to explicitly grant this permission.

## Notes
The project is intentionally dependency-light and uses native Android Views so it is easy to continue customizing. The first version uses a polished functional shell; the next iteration can add richer illustrations, animations, subject tracking, detailed statistics, and a larger achievement catalogue.
