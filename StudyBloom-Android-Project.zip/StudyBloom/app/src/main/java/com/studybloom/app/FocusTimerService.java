package com.studybloom.app;

import android.app.*;
import android.content.*;
import android.os.*;

public class FocusTimerService extends Service {
    public static final String START="START", STOP="STOP", TYPE="type", SECONDS="seconds";
    public static final String ACTION_TICK="com.studybloom.app.TICK", ACTION_DONE="com.studybloom.app.DONE";
    private CountDownTimer timer; private long started; private boolean focus;
    private NotificationManager nm;
    @Override public void onCreate(){super.onCreate(); nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE); if(Build.VERSION.SDK_INT>=26) nm.createNotificationChannel(new NotificationChannel("timer","Study Timer",NotificationManager.IMPORTANCE_LOW));}
    @Override public int onStartCommand(Intent i,int flags,int id){
        if(i==null) return START_STICKY;
        if(STOP.equals(i.getAction())){ if(timer!=null)timer.cancel(); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf(); return START_NOT_STICKY; }
        if(START.equals(i.getAction())) startTimer(i.getIntExtra(SECONDS,1500), i.getBooleanExtra(TYPE,true));
        return START_STICKY;
    }
    private void startTimer(int seconds,boolean isFocus){
        if(timer!=null)timer.cancel(); focus=isFocus; started=System.currentTimeMillis();
        Intent b=new Intent(ACTION_TICK); b.setPackage(getPackageName()); sendBroadcast(b);
        timer=new CountDownTimer(seconds*1000L,1000){
            boolean warned=false;
            public void onTick(long left){
                long s=left/1000; if(s<=60&&!warned){warned=true; post("⏰ 1 minute left",(int)s);} else post("StudyBloom • "+fmt(s),(int)s);
                Intent x=new Intent(ACTION_TICK).setPackage(getPackageName()).putExtra("left",(int)s).putExtra("focus",focus); sendBroadcast(x);
            }
            public void onFinish(){
                if(focus) StatsStore.addFocus(FocusTimerService.this,(int)((System.currentTimeMillis()-started)/1000)); else StatsStore.addBreak(FocusTimerService.this,(int)((System.currentTimeMillis()-started)/1000));
                post(focus?"🌱 Focus complete!":"☕ Break complete!",0);
                Intent x=new Intent(ACTION_DONE).setPackage(getPackageName()).putExtra("focus",focus); sendBroadcast(x);
                stopForeground(STOP_FOREGROUND_DETACH); stopSelf();
            }
        }; timer.start(); startForeground(7,build("StudyBloom • starting…"));
    }
    private void post(String text,int sec){ nm.notify(7,build(text)); }
    private Notification build(String text){
        Intent open=new Intent(this,MainActivity.class); PendingIntent pi=PendingIntent.getActivity(this,0,open,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        return new Notification.Builder(this,"timer").setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("StudyBloom").setContentText(text).setContentIntent(pi).setOngoing(true).build();
    }
    private String fmt(long s){return String.format(java.util.Locale.US,"%02d:%02d",s/60,s%60);}
    @Override public void onDestroy(){if(timer!=null)timer.cancel();super.onDestroy();}
    @Override public android.os.IBinder onBind(Intent intent){return null;}
}
