package com.studybloom.app;

import android.content.Context;
import android.content.SharedPreferences;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public final class StatsStore {
    private static final String P="studybloom";
    private StatsStore(){}
    static SharedPreferences p(Context c){ return c.getSharedPreferences(P, Context.MODE_PRIVATE); }
    static int focusMin(Context c){ return p(c).getInt("focusMin",25); }
    static int breakMin(Context c){ return p(c).getInt("breakMin",5); }
    static int longBreakMin(Context c){ return p(c).getInt("longBreakMin",15); }
    static int today(Context c){ return p(c).getInt("todaySeconds",0); }
    static int breakToday(Context c){ return p(c).getInt("breakSeconds",0); }
    static int streak(Context c){ return p(c).getInt("streak",0); }
    static int coins(Context c){ return p(c).getInt("coins",0); }
    static int totalSessions(Context c){ return p(c).getInt("totalSessions",0); }
    static int unlockedForest(Context c){ return p(c).getInt("forestUnlocked",1); }
    static int unlockedAquarium(Context c){ return p(c).getInt("aquariumUnlocked",1); }
    static String lastDay(Context c){ return p(c).getString("lastStudyDay",""); }
    static void addFocus(Context c,int seconds){
        SharedPreferences q=p(c); int today=q.getInt("todaySeconds",0)+seconds; int sess=q.getInt("totalSessions",0)+1;
        int coins=q.getInt("coins",0)+Math.max(1,seconds/60);
        String now=LocalDate.now().toString(), last=q.getString("lastStudyDay",""); int st=q.getInt("streak",0);
        boolean reachedMinimum=today>=600;
        if(reachedMinimum && !now.equals(last)){
            if(last.isEmpty()) st=1; else { long d=0; try{d=ChronoUnit.DAYS.between(LocalDate.parse(last),LocalDate.now());}catch(Exception ignored){} st=(d==1?st+1:1); }
            q.edit().putString("lastStudyDay",now).putInt("streak",st).apply();
        }
        q.edit().putInt("todaySeconds",today).putInt("totalSessions",sess).putInt("coins",coins).apply();
    }
    static void addBreak(Context c,int seconds){ p(c).edit().putInt("breakSeconds",breakToday(c)+seconds).apply(); }
    static void resetDailyIfNeeded(Context c){
        SharedPreferences q=p(c); String today=LocalDate.now().toString(), marker=q.getString("dayMarker","");
        if(!today.equals(marker)) q.edit().putString("dayMarker",today).putInt("todaySeconds",0).putInt("breakSeconds",0).apply();
    }
    static void setSetting(Context c,String k,int v){p(c).edit().putInt(k,v).apply();}
    static boolean bool(Context c,String k,boolean d){return p(c).getBoolean(k,d);}
    static void setBool(Context c,String k,boolean v){p(c).edit().putBoolean(k,v).apply();}
    static void unlock(Context c, boolean forest){
        SharedPreferences q=p(c); String key=forest?"forestUnlocked":"aquariumUnlocked"; int n=q.getInt(key,1);
        int cost=20+n*15; if(q.getInt("coins",0)>=cost && n<26) q.edit().putInt("coins",q.getInt("coins",0)-cost).putInt(key,n+1).apply();
    }
}
