package com.studybloom.app;

import android.accessibilityservice.AccessibilityService;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.view.*;
import android.widget.*;
import android.view.accessibility.AccessibilityEvent;
import java.util.*;

public class StudyBloomAccessibilityService extends AccessibilityService {
    private View overlay;
    private final Set<String> blocked=new HashSet<>(Arrays.asList("com.google.android.youtube","com.instagram.android","com.snapchat.android","com.facebook.katana","com.reddit.frontpage"));
    @Override public void onAccessibilityEvent(AccessibilityEvent e){
        if(!StatsStore.bool(this,"blockApps",false)) {remove(); return;}
        if(e.getEventType()!=AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED)return;
        CharSequence pkg=e.getPackageName(); if(pkg!=null && blocked.contains(pkg.toString())) show(); else remove();
    }
    private void show(){ if(overlay!=null)return; TextView t=new TextView(this); t.setText("📚  Focus mode\n\nThis app is paused while your StudyBloom session is running.\n\nFinish your focus session first 🌱"); t.setTextColor(Color.WHITE); t.setTextSize(20); t.setGravity(Gravity.CENTER); t.setPadding(60,60,60,60); t.setBackgroundColor(Color.rgb(7,22,46));
        WindowManager.LayoutParams lp=new WindowManager.LayoutParams(-1,-1,WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN|WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT); getSystemService(WindowManager.class).addView(t,lp); overlay=t; }
    private void remove(){if(overlay!=null){try{getSystemService(WindowManager.class).removeView(overlay);}catch(Exception ignored){} overlay=null;}}
    @Override public void onInterrupt(){}
    @Override public void onDestroy(){remove();super.onDestroy();}
}
